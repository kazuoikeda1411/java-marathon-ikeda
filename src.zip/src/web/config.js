const config = {
  apiUrl: 'http://localhost:3508'
};

export default config;